
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/" | "/products";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/products": Record<string, never>
		};
		Pathname(): "/" | "/products";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/img/butterfly.jpg" | "/img/cactus.jpg" | "/img/fern.jpg" | "/img/herbs.jpg" | "/img/hydrangea.jpg" | "/img/lavender.jpg" | "/img/roses.jpg" | "/img/succulent.jpg" | "/img/tomato-plant.jpg" | "/robots.txt" | string & {};
	}
}