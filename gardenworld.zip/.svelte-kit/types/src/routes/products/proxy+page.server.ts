// @ts-nocheck
import { db, initDb } from '$lib/server/db';
import { products } from '$lib/server/db/schema';
import type { PageServerLoad } from './$types';

export const load = async () => {
	await initDb();

	const productList = await db.select().from(products);

	return { products: productList };
};
;null as any as PageServerLoad;