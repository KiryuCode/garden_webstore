import { t as __exportAll } from "../../../chunks/chunk.js";
import { createClient } from "@libsql/client";
import { drizzle } from "drizzle-orm/libsql";
import { integer, real, sqliteTable, text } from "drizzle-orm/sqlite-core";
import { count } from "drizzle-orm";
//#region src/lib/server/db/schema.ts
var schema_exports = /* @__PURE__ */ __exportAll({ products: () => products });
var products = sqliteTable("products", {
	id: integer("id").primaryKey({ autoIncrement: true }),
	name: text("name").notNull(),
	description: text("description").notNull(),
	price: real("price").notNull(),
	imageUrl: text("image_url")
});
var db = drizzle(createClient({ url: "file:local.db" }), { schema: schema_exports });
//#endregion
//#region src/lib/server/db/seed.ts
var sampleProducts = [
	{
		name: "Tomato Plant",
		description: "Home-grown tomato plant, ready for your garden.",
		price: 12.99,
		imageUrl: "/img/tomato-plant.jpg"
	},
	{
		name: "Mechanical Keyboard",
		description: "Compact 75% layout with hot-swappable switches and RGB backlight.",
		price: 89.99,
		imageUrl: "/img/hydrangea.jpg"
	},
	{
		name: "USB-C Hub",
		description: "7-in-1 adapter with HDMI, SD card reader, and 100W pass-through charging.",
		price: 49.99,
		imageUrl: "/img/cactus.jpg"
	},
	{
		name: "Portable Monitor",
		description: "15.6\" 1080p IPS display for travel and dual-screen setups.",
		price: 199.99,
		imageUrl: "/img/roses.jpg"
	},
	{
		name: "Basil Plant",
		description: "Fresh basil plant, perfect for cooking.",
		price: 9.99,
		imageUrl: "/img/herbs.jpg"
	},
	{
		name: "Garden Plant",
		description: "Grown locally.",
		price: 14.99,
		imageUrl: "/img/fern.jpg"
	}
];
async function seedProducts() {
	const [{ value }] = await db.select({ value: count() }).from(products);
	if (value === 0) await db.insert(products).values(sampleProducts);
}
//#endregion
//#region src/lib/server/db/index.ts
var initialized = false;
async function initDb() {
	if (initialized) return;
	await seedProducts();
	initialized = true;
}
//#endregion
//#region src/routes/products/+page.server.ts
var load = async () => {
	await initDb();
	return { products: await db.select().from(products) };
};
//#endregion
export { load };
