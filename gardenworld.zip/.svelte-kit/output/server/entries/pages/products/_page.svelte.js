import { _ as attr, n as ensure_array_like, r as head, v as escape_html } from "../../../chunks/server.js";
//#region src/routes/products/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		const formatter = new Intl.NumberFormat("en-US", {
			style: "currency",
			currency: "USD"
		});
		head("1dj9mz1", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Merchandise</title>`);
			});
		});
		$$renderer.push(`<main class="page svelte-1dj9mz1"><header class="header svelte-1dj9mz1"><a href="/" class="home-link svelte-1dj9mz1">Home</a> <h1 class="svelte-1dj9mz1">Merchandise</h1></header> `);
		if (data.products.length === 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<p class="empty svelte-1dj9mz1">No merchandise found.</p>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<ul class="grid svelte-1dj9mz1"><!--[-->`);
			const each_array = ensure_array_like(data.products);
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let product = each_array[$$index];
				$$renderer.push(`<li class="card svelte-1dj9mz1">`);
				if (product.imageUrl) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<img class="card-image svelte-1dj9mz1"${attr("src", product.imageUrl)}${attr("alt", product.name)}/>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <div class="card-body svelte-1dj9mz1"><h2 class="svelte-1dj9mz1">${escape_html(product.name)}</h2> <p class="description svelte-1dj9mz1">${escape_html(product.description)}</p> <p class="price svelte-1dj9mz1">${escape_html(formatter.format(product.price))}</p></div></li>`);
			}
			$$renderer.push(`<!--]--></ul>`);
		}
		$$renderer.push(`<!--]--></main>`);
	});
}
//#endregion
export { _page as default };
