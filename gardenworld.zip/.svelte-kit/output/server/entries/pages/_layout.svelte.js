import { _ as attr, r as head } from "../../chunks/server.js";
//#region src/lib/assets/favicon.svg
var favicon_default = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%20role='img'%20aria-label='Garden'%3e%3crect%20width='32'%20height='32'%20rx='7'%20fill='%230f766e'%20/%3e%3cellipse%20cx='16'%20cy='26.5'%20rx='9'%20ry='2'%20fill='%2314532d'%20opacity='0.55'%20/%3e%3cpath%20d='M16%2025.5V14.5'%20stroke='%2386efac'%20stroke-width='2.2'%20stroke-linecap='round'%20fill='none'%20/%3e%3cpath%20d='M16%2019.5C12.5%2017.5%209%2018.5%207.5%2021'%20stroke='%234ade80'%20stroke-width='2'%20stroke-linecap='round'%20fill='none'%20/%3e%3cpath%20d='M16%2016.5C19.5%2014.5%2023%2015.5%2024.5%2018'%20stroke='%234ade80'%20stroke-width='2'%20stroke-linecap='round'%20fill='none'%20/%3e%3ccircle%20cx='16'%20cy='11.5'%20r='3.2'%20fill='%23fde68a'%20/%3e%3ccircle%20cx='13.8'%20cy='10.2'%20r='2'%20fill='%23fbbf24'%20/%3e%3ccircle%20cx='18.2'%20cy='10.2'%20r='2'%20fill='%23fbbf24'%20/%3e%3ccircle%20cx='16'%20cy='13.2'%20r='2'%20fill='%23fbbf24'%20/%3e%3ccircle%20cx='16'%20cy='10.8'%20r='1.1'%20fill='%23d97706'%20/%3e%3c/svg%3e";
//#endregion
//#region src/routes/+layout.svelte
function _layout($$renderer, $$props) {
	let { children } = $$props;
	head("12qhfyh", $$renderer, ($$renderer) => {
		$$renderer.push(`<link rel="icon"${attr("href", favicon_default)}/>`);
	});
	children($$renderer);
	$$renderer.push(`<!---->`);
}
//#endregion
export { _layout as default };
