export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["img/butterfly.jpg","img/cactus.jpg","img/fern.jpg","img/herbs.jpg","img/hydrangea.jpg","img/lavender.jpg","img/roses.jpg","img/succulent.jpg","img/tomato-plant.jpg","robots.txt"]),
	mimeTypes: {".jpg":"image/jpeg",".txt":"text/plain"},
	_: {
		client: {start:"_app/immutable/entry/start.CnyCidVq.js",app:"_app/immutable/entry/app.Ci5JMo-V.js",imports:["_app/immutable/entry/start.CnyCidVq.js","_app/immutable/chunks/DtVqA6Fg.js","_app/immutable/chunks/BllK_S9N.js","_app/immutable/entry/app.Ci5JMo-V.js","_app/immutable/chunks/BllK_S9N.js","_app/immutable/chunks/kNaey6uv.js","_app/immutable/chunks/xihTtKlq.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/products",
				pattern: /^\/products\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
