<script lang="ts">
	let { data } = $props();

	const formatter = new Intl.NumberFormat('en-US', {
		style: 'currency',
		currency: 'USD'
	});
</script>

<svelte:head>
	<title>Merchandise</title>
</svelte:head>

<main class="page">
	<header class="header">
		<a href="/" class="home-link">Home</a>
		<h1>Merchandise</h1>
	</header>

	{#if data.products.length === 0}
		<p class="empty">No merchandise found.</p>
	{:else}
		<ul class="grid">
			{#each data.products as product (product.id)}
				<li class="card">
					{#if product.imageUrl}
						<img class="card-image" src={product.imageUrl} alt={product.name} />
					{/if}
					<div class="card-body">
						<h2>{product.name}</h2>
						<p class="description">{product.description}</p>
						<p class="price">{formatter.format(product.price)}</p>
					</div>
				</li>
			{/each}
		</ul>
	{/if}
</main>

<style>
	.page {
		max-width: 960px;
		margin: 0 auto;
		padding: 2rem 1.5rem 3rem;
		font-family: system-ui, sans-serif;
		color: #1a1a1a;
	}

	.header {
		position: relative;
		margin-bottom: 2rem;
		text-align: center;
	}

	.home-link {
		position: absolute;
		top: 0;
		left: 0;
		color: #047857;
		font-weight: 600;
		font-size: 0.95rem;
		text-decoration: underline;
		text-underline-offset: 0.2em;
	}

	.home-link:hover {
		color: #065f46;
	}

	h1 {
		margin: 0;
		font-size: 2rem;
		color: #047857;
	}

	.empty {
		color: #666;
	}

	.grid {
		display: grid;
		grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
		gap: 1rem;
		list-style: none;
		padding: 0;
		margin: 0;
	}

	.card {
		border: 1px solid #e5e5e5;
		border-radius: 12px;
		background: #fff;
		box-shadow: 0 1px 3px rgb(0 0 0 / 6%);
		overflow: hidden;
	}

	.card-image {
		display: block;
		width: 100%;
		height: 180px;
		object-fit: cover;
	}

	.card-body {
		padding: 1.25rem;
	}

	h2 {
		margin: 0 0 0.5rem;
		font-size: 1.125rem;
	}

	.description {
		margin: 0 0 1rem;
		color: #555;
		line-height: 1.5;
		font-size: 0.95rem;
	}

	.price {
		margin: 0;
		font-weight: 700;
		font-size: 1.1rem;
		color: #6baed6;
	}
</style>
