import { integer, real, sqliteTable, text } from 'drizzle-orm/sqlite-core';

export const products = sqliteTable('products', {
	id: integer('id').primaryKey({ autoIncrement: true }),
	name: text('name').notNull(),
	description: text('description').notNull(),
	price: real('price').notNull(),
	imageUrl: text('image_url')
});

export type Product = typeof products.$inferSelect;
