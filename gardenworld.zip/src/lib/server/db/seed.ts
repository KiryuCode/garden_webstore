import { count } from 'drizzle-orm';
import { db } from './connection';
import { products } from './schema';

const sampleProducts = [
	{
		name: 'Tomato Plant',
		description: 'Home-grown tomato plant, ready for your garden.',
		price: 12.99,
		imageUrl: '/img/tomato-plant.jpg'
	},
	{
		name: 'Mechanical Keyboard',
		description: 'Compact 75% layout with hot-swappable switches and RGB backlight.',
		price: 89.99,
		imageUrl: '/img/hydrangea.jpg'
	},
	{
		name: 'USB-C Hub',
		description: '7-in-1 adapter with HDMI, SD card reader, and 100W pass-through charging.',
		price: 49.99,
		imageUrl: '/img/cactus.jpg'
	},
	{
		name: 'Portable Monitor',
		description: '15.6" 1080p IPS display for travel and dual-screen setups.',
		price: 199.99,
		imageUrl: '/img/roses.jpg'
	},
	{
		name: 'Basil Plant',
		description: 'Fresh basil plant, perfect for cooking.',
		price: 9.99,
		imageUrl: '/img/herbs.jpg'
	},
	{
		name: 'Garden Plant',
		description: 'Grown locally.',
		price: 14.99,
		imageUrl: '/img/fern.jpg'
	}
];

export async function seedProducts() {
	const [{ value }] = await db.select({ value: count() }).from(products);

	if (value === 0) {
		await db.insert(products).values(sampleProducts);
	}
}
