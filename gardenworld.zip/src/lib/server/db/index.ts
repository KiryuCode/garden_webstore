import { db } from './connection';
import { seedProducts } from './seed';

export { db } from './connection';

let initialized = false;

export async function initDb() {
	if (initialized) return;

	await seedProducts();
	initialized = true;
}
